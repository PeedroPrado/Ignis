
-- 🏗️ Criação da tabela
CREATE TABLE public.risco (
    id integer NOT NULL,
    data date,
    geometria geometry(Point, 4674),
    estado_id integer,
    bioma_id integer,
    risco_fogo real
);

ALTER TABLE public.risco OWNER TO postgres;

-- 🔑 Chave Primária
ALTER TABLE ONLY public.risco
    ADD CONSTRAINT risco_pkey PRIMARY KEY (id);

-- 🔍 Índices
CREATE INDEX idx_bioma ON public.risco USING btree (bioma_id);
CREATE INDEX idx_estado ON public.risco USING btree (estado_id);
CREATE INDEX idx_geom ON public.risco USING gist (geometria);
CREATE INDEX idx_risco_bioma ON public.risco USING btree (bioma_id);
CREATE INDEX idx_risco_data ON public.risco USING btree (data);
CREATE INDEX idx_risco_estado ON public.risco USING btree (estado_id);
CREATE INDEX idx_risco_estado_bioma_data ON public.risco USING btree (estado_id, bioma_id, data);
CREATE INDEX idx_risco_geom ON public.risco USING gist (geometria);
CREATE INDEX idx_riscofogo ON public.risco USING btree (risco_fogo);

-- 🚚 Importação dos dados do CSV
COPY public.risco (id, data, geometria, estado_id, bioma_id, risco_fogo)
FROM 'C:/Users/pedro/OneDrive/Desktop/conversor/risco_inserts_optimized.csv'
DELIMITER ',' CSV HEADER;

-- 🔄 Conversão do campo geometria de HEX para GEOMETRY
UPDATE public.risco
SET geometria = ST_SetSRID(ST_GeomFromWKB(decode(geometria, 'hex')), 4674);

-- 🔍 Conferência dos dados
SELECT COUNT(*) AS total_registros,
       COUNT(*) FILTER (WHERE risco_fogo = 0) AS registros_com_risco_zero
FROM public.risco;

-- ❌ (Opcional) Remoção dos registros com risco igual a zero
DELETE FROM public.risco
WHERE risco_fogo = 0;

-- 🔍 Conferência final
SELECT COUNT(*) AS registros_restantes
FROM public.risco;
